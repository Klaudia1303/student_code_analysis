a=float(input("eta cane"))
if a<=2 :
    print(a*10.5)
else :
     print((a-2)*4+21)
