s=input('inserire una stringa:')
i=0
x=0
while i+1<(len(s):
        if s[i]==s[i+1]:
            x=s.count(s[i])
            carattere=s[i]
     i+=1
print(carattere,x)
        
