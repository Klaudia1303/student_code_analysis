a=int(input('inserire un numero '))
b=int(input('inserire un numero '))
if a<b:
    print('propria')
elif a%b==0:
    print('apparente')
else:
    print('impropria')
