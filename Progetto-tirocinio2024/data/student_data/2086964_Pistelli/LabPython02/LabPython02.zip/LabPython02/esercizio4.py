a=str(input('inserire una parola '))
b=a[0]
c=a[len(a)-1]
if b==c:
    print('catatteri' , b ,'e' , c, 'sono uguali')
else:
     print('catatteri' , b ,'e' , c, 'sono diversi')
