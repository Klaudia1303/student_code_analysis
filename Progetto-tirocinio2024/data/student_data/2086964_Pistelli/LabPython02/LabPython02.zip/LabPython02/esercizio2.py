a=str(input('inserici una parola'))
b=len(a)
c=a*b
print(c)
