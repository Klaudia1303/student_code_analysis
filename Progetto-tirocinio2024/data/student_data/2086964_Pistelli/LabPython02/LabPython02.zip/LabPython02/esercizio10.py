a=int(input('inserire eta del cane '))
if a==2:
    print('21')
if a==1:
    print('10.5')    
if a>2:
    print(21+((a-2)*4))
