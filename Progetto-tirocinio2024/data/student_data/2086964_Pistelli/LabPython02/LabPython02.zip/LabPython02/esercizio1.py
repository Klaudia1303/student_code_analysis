h=int(input('inserire le ore '))
m=int(input('inserire i minuti '))
s=int(input('inserire i seondi '))
a=(h*60*60)+(m*60)+s
print(a)
