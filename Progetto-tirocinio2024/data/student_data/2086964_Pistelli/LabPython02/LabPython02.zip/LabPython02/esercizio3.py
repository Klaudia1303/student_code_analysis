a=int(input('inserire un numero '))
b=str(input('inserire una parola '))
if a%2==1:
    print(b)
else:
    print(' inl numero è pari')
